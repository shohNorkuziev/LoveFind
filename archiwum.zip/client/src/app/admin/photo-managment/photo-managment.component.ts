import { Component } from '@angular/core';

@Component({
  selector: 'app-photo-managment',
  templateUrl: './photo-managment.component.html',
  styleUrls: ['./photo-managment.component.scss']
})
export class PhotoManagmentComponent {

}
