export interface MessageThreadInfo {
    photoUrl : string;
    username: string
    content: string;
    dateRead :Date;
}